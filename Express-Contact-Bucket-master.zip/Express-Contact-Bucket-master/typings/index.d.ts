/// <reference path="globals/mongoose/index.d.ts" />
