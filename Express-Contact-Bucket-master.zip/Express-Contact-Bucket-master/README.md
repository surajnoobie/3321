# Express-Contact-Bucket
[![HitCount](http://hits.dwyl.com/parikshit223933/Express-Contact-Bucket.svg)](http://hits.dwyl.com/parikshit223933/Express-Contact-Bucket)

# How to Run
1. Install NodeJs (nodejs.org).
2. Fork, Clone and open this repository in a terminal/command prompt.
3. Execute `npm install`.
4. Execute `npm start`.
5. Open your preferred web browser and go to `https://localhost:8000`.

Please make sure that you are connected to the internet for a better visual experience. Another reason is that this app uses fonts from google.

# Features
1. Add a Contact
2. Remove a contact

These contacts will be saved in a MongoDB DataBase.

# Screenshots
<img src="./assets/repo resources/sc.PNG">
